<?php exit(); ?> Time: 2017-07-04 08:56:42. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-04 08:56:43. || Page: /phpMyWind/admin/login.php || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-04 08:56:58. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-04 16:20:28. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
