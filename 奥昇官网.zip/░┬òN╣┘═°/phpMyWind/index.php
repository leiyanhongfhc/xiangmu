<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>


<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>

	<link rel="stylesheet" href="css/bootstrap.min.css"/> 
	<link rel="stylesheet" href="css/home.css"/>
	<link rel="stylesheet" href="css/common.css"/>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="banner">
	<div id="slideplay">
		<ul>
			<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=13 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<li><a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a></li>
			<?php
			}
			?>
		</ul>
	</div>
</div>
<!-- /banner-->


 <!-- start 解决方案 -->
       <div class="solution">
		<div class="aorise-title">
			<a href="solution.php">解决方案/Solution More</a>
		</div>
		<div class="aorise-wrap"></div>
		<div class="s-content">
			<div class="container">
				<div class="row">
				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14  AND  flag LIKE '%a%'  AND  delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,3");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>

                    <div class="col-lg-4 col-md-4 col-xs-4" >

                        <div class="s-content-image">
							<div class="s-image">
								<a href=""> <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"></a>
							</div>
							<div class="s-image-title"><a href="#"><?php echo $row['title']; ?></a></div>
						</div>
                    </div>
                    <?php
			         }
			         ?>
				</div>
			</div>		
		</div>
	</div>
	

<!-- end 解决方案 -->


  <!--  关于我们-->
   <div class="solution">
		<div class="aorise-title">
			<a href="about.php">关于我们/About Us More</a>
		</div>
	<div class="aorise-wrap"></div>
	  <div class="container">
	    <div class="row">

	     <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=15 AND  flag LIKE '%s%'  AND  delstate='' AND checkinfo=true ORDER BY orderid asc  LIMIT 0,4");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
          <div class="total-hexagon">
		    <div class=" < imgs  col-md-3 col-lg-3 col-xs-3">
    
		   <a href="#"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a>

		    
		    <p><a href="#"><?php echo $row['title']; ?></a></p>
        </div>
         <?php
			         }
			         ?>
        </div>
  </div>
</div>
</div>
<!-- 新闻资讯/NEWS More -->

    <div class="solution">
		<div class="aorise-title1">
			<a href="news.php">新闻资讯/NEWS More</a>
			<div class="aorise-wrap"></div>
		</div>
	</div>
      <div class="container">
      <div class="row">
       <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=16 AND  flag LIKE '%%'  AND  delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,1");
              while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
		 <div class="wit col-md-6 col-xs-6 col-lg-6" >
         <a href="#"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a>
         <div class="p-wrapa">     
		            <?php echo $row['content']; ?>
	   </div>
          
          <?php
			         }
			         ?>
     </div>
     
	<?php
		$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=16 AND  flag LIKE '%b%'  AND  delstate='' AND checkinfo=true ORDER BY orderid ASC   LIMIT 0,8");
       while($row = $dosql->GetArray())
             {
		   if($row['linkurl'] != '')$gourl = $row['linkurl'];
		 else $gourl = 'javascript:;';
			?>
          <div class="content s-wrapa col-md-6 col-xs-6 col-lg-6">		 	
        <ul>
        <div > </div>
        <li>
        <a href="<?php echo $row['picurl']; ?>"><?php echo $row['title']; ?>
        

        </li>
        </ul>
        </div>
		<?php
      }
	   ?>	         
      </div>
    </div>

	<?php require_once('footer.php'); ?>

</body>
</html>

