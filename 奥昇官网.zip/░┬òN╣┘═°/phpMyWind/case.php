<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 8 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<link rel="stylesheet" href="css/bootstrap.min.css"/> 
	<link rel="stylesheet" href="css/case-Study.css"/>
	<link rel="stylesheet" href="css/common.css"/>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
 



   <div class="container">
      <div class="row">
     <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=20 AND  flag LIKE '%a%'  AND  delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
	   <div class="col-lg-12 col-md-12">
	    <div class="bg"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></div>
	    <?php
			}
			?>

	    </div>
	    </div>
	    </div>



<div class="container">
       <div class="row">
         <div class="col-md-12 col-lg-12 col-xs-12">
	        <div class="Solution-More1">案例展示<span>您当前的位置：<a href="lesson.html"> 首页</a>><a href="Solution-More.html">案例展示</a></span>
	       </div>
        </div>
      </div>
     </div>
     <div class="container">
	   <div class="row">
		<div class="bottom1"></div>
		<div class="Solution-More2">案例展示</div>
		<div class="bottom2"></div>
		</div>
		</div>	
	 <div class="container">
	   <div class="row">
	   <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=20 AND  flag LIKE '%%'  AND  delstate='' AND checkinfo=true ORDER BY orderid asc   LIMIT 0,5");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

	   <div class="col-md-4 col-lg-4 col-xs-4">
             <div class="imgs"><a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a><p><?php echo $row['title']; ?></p></div>
        </div> 
       
  	              <?php
			         }
			         ?>
	       </div> 
	   </div>
	 </div>





<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>