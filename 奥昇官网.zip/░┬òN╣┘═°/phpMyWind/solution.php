<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>


<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>

	<link rel="stylesheet" href="css/bootstrap.min.css"/> 
	<link rel="stylesheet" href="css/Solution-More.css"/>
	<link rel="stylesheet" href="css/common.css"/>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- bg-->
 <div class="container">
      <div class="row">
     <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=17 AND  flag LIKE '%a%'  AND  delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
	   <div class="col-lg-12 col-md-12">
	    <div class="bg"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></div>
	    <?php
			}
			?>

	    </div>
	    </div>
	    </div>
<!-- /bg-->
<!-- 解决方案 -->
 <div class="container">
       <div class="row">
         <div class="col-md-12 col-lg-12 col-xs-12">
	        <div class="Solution-More1">解决方案<span>您当前的位置：<a href="lesson.html"> 首页</a>><a href="Solution-More.html">解决方案</a></span>
	       </div>
        </div>
      </div>
     </div>
     <div class="container">
	   <div class="row">
		<div class="bottom1"></div>
		<div class="Solution-More2">解决方案</div>
		<div class="bottom2"></div>
		</div>
		</div>


		<div class="container">
	  <div class="row">
	  <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=17 AND  flag LIKE '%h%'  AND  delstate='' AND checkinfo=true ORDER BY orderid asc   LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<div class="s-tu">
			<div class="col-md-4 col-lg-4 col-xs-4">
			
			   <a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['content']; ?>" /></a>
			
			</div>
                
			<div class="col-md-8 col-lg-8 col-xs-8">
			<div class="centen">
                 <a href="#"><?php echo $row['content']; ?></a>
			</div>
			</div>
			</div>
			
			<?php
			}
			?>
		  </div>
		  </div>

	    
	     <!-- 
	     <div class="centen"> -->
	 	<!-- <ul>   
           <li><span>湖南奥昇信息互联网+监督 项目...</span></br><time datetime="2017-03-28">时间：2017-03-28</time></br>互联网+监督是践行党的群众路线，密切干群关系最直观的体现。其优势表现在通过大数据分析各种数据进行排查、提炼各种有效信息，协助纪律检查部门，缩小排查范围，有针对性的对各种纪律违章情况进行处理。并通过互联网的手段，使得群众亦可不出门便掌握的信息进行反馈和跟踪。这是一种趋势，是适应大数据.....</li>
            </ul> -->
	
<!-- end解决方案 -->



 
	<?php require_once('footer.php'); ?>

</body>
</html>

