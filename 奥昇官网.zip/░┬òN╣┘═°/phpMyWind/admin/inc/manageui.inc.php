<?php	if(!defined('IN_PHPMYWIND')) exit('Request Error!');

$cfg_loginbgimg = 'templates/images/loginbg/loginBg_02.jpg';
$cfg_loginbgcolor = '';
$cfg_loginbgrepeat = '1';
$cfg_loginbgpos = '1';

?>