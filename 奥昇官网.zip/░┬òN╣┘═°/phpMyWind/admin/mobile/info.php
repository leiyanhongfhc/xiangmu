<?php	if(!defined('IN_MOBILE')) exit('Request Error!'); ?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>PHPMyWind 管理中心</title>
<link href="mobile/templates/style/mobile.css" rel="stylesheet" type="text/css" />
<script src="mobile/templates/js/jquery.min.js"></script>
<script src="mobile/templates/js/frame.js"></script>
</head>

<body>
<?php require_once('header.php'); ?>
<div class="mobileBody"> 当前不支持，请切换电脑版进行管理 </div>
<?php require_once('footer.php'); ?>
</body>
</html>