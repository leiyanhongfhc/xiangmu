// $(function(){
// 	$(".carousel-indicators li").click(function() {
// 		$(this).addClass('actived').siblings().removeClass('actived');
// 	});
// 	$(".carousel-control img").click(function() {
		
// 		/* Act on the event */
// 	});
// })