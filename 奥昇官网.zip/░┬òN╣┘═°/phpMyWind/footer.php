<!-- weblink-->
<link rel="stylesheet" href="css/bootstrap.min.css"/> 
  <link rel="stylesheet" href="css/common.css"/>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>


  <footer >
   <div class="container"> 
    <div class="row">
    <?php
      $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=19 AND  flag LIKE '%%'  AND  delstate='' AND checkinfo=true ORDER BY orderid asc   LIMIT 0,1");
              while($row = $dosql->GetArray())
      {
        if($row['linkurl'] != '')$gourl = $row['linkurl'];
        else $gourl = 'javascript:;';
      ?>
  <div class="foot">
   <div class=" col-md-12 col-xs-12 col-lg-12 ">
     <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['content']; ?>" />
      <p><?php echo $row['content']; ?></p>
   </div> 
     <div class="qr_code"> <img src="Images/scanCode.PNG"></div>
      <?php
      }
      ?>
     </div>
    </div>
   </div>
 </footer>
<!-- /weblink-->
<!-- footer-->
 